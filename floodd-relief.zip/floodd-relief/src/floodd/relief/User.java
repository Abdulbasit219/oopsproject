/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package floodd.relief;

/**
 *
 * @author Aazan
 */
class User {
    private int donorid;
    private String name,fname,mobile,DOB,gender,email,bloodgroup,quantity,address;
    
    public User(int donorid, String name, String fname, String mobile, String DOB, String gender,String email, String bloodgroup, String quantity, String address){
        this.donorid = donorid;
        this.name = name;
        this.fname = fname;
        this.mobile = mobile;
        this.DOB = DOB;
        this.address = address;
        this.bloodgroup = bloodgroup;
        this.quantity = quantity;
        this.gender = gender;
        this.email = email;
    }
    public int getdonorid(){
        return donorid;
    }
    public String getname(){
        return name;
    }
     public String getfname(){
        return fname;
    }
      public String getDOB(){
        return DOB;
    }
       public String getmobile(){
        return mobile;
    }
        public String getemail(){
        return email;
    }
        public String getquantity(){
        return quantity;
    } 
        public String getaddress(){
        return address;
    }
        public String getgender(){
        return gender;
    }
        public String getbloodgroup(){
        return bloodgroup;
    }
        
}
