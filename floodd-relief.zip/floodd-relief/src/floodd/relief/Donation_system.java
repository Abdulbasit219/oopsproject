
package floodd.relief;


public class Donation_system {

    
    public static void main(String[] args) {
        
    }
    
}
