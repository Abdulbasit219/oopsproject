/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package floodd.relief;

/**
 *
 * @author Aazan
 */
class Userregisteration {
    int sr;
    private String name,fname,contact,email,cnic,address,password;
    
        public Userregisteration(int sr, String name, String fname, String contact, String cnic, String address,String email, String password){
        this.sr = sr;
        this.name = name;
        this.fname = fname;
        this.contact = contact;
        this.cnic = cnic;
        this.address = address;
        this.email = email;
        this.password = password;
    }
    public int getsr(){
        return sr;
    }
    public String getname(){
        return name;
    }
     public String getfname(){
        return fname;
    }
     public String getcontact(){
        return contact;
    }
        public String getemail(){
        return email;
    }
        public String getpassword(){
        return password;
    } 
        public String getcnic(){
        return cnic;
    }
        public String getaddress(){
        return address;
    }
   
}
