/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package floodd.relief;

/**
 *
 * @author Aazan
 */
class Userf {
     private int donorid;
    private String name,fname,mobile,DOB,gender,email,quantity,type,city,address;
    
        public Userf(int donorid, String name, String fname, String mobile, String DOB, String gender,String email, String quantity, String type, String city, String address){
        this.donorid = donorid;
        this.name = name;
        this.fname = fname;
        this.mobile = mobile;
        this.DOB = DOB;
        this.address = address;
        this.quantity=quantity;
        this.type = type;
        this.city = city;
        this.gender = gender;
        this.email = email;
    }
    public int getdonorid(){
        return donorid;
    }
    public String getname(){
        return name;
    }
     public String getfname(){
        return fname;
    }
      public String getDOB(){
        return DOB;
    }
       public String getmobile(){
        return mobile;
    }
        public String getemail(){
        return email;
    }
        public String getcity(){
        return city;
    } 
        public String getaddress(){
        return address;
    }
        public String getgender(){
        return gender;
    }
        public String getquantity(){
        return quantity;
    }
        public String gettype(){
            return type;
        }
    
}
