/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package floodd.relief;
/**
 *
 * @author Aazan
 */
class Usercash {
     private int ID1;
    private String Name1,Ammount1;
    
        public Usercash(int ID1, String Name1, String Ammount1){
        this.ID1 = ID1;
        this.Name1 = Name1;
       // this.Contact1 = Contact1;
       // this.Cnic1 = Cnic1;
        this.Ammount1 = Ammount1;
        
    }
    public int getID1(){
        return ID1;
    }
    public String getName1(){
        return Name1;
    }
   
    public String getAmmount1(){
        return Ammount1;
    }
     
}
